<?php include "includes/db.php"?>
<!DOCTYPE html>
<html lang="en">

<?php include "includes/adminheader.php"?>

<body>

    <div id="wrapper">
<?php include "includes/adminnavigasi.php"?>
        <!-- Navigation -->
        
        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Categori
                            <small>Subheading</small>
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="index.html">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-file"></i> Blank Page
                            </li>
                        </ol>
<div class="col-xs-6">
							<form action=""></form>
								<div class="form-group">
									<label for="cat_judul">Tambah Categori</label>
									<input type="text" class="form-control" name="cat_judul">
								</div>
								<div class="form-group">
									<input class="btn btn-primary" type="submit" name="submit" value="add category">
								</div>
						</div>
						<div class="col-xs-6">
							<?php
							$query = "SELECT * FROM Categories";
							$pilih_categories = mysqli_query($connection,$query);?>
							
							<table class="table table-bordered table-hover">
								<thead>
									<tr>
										<th>Id</th>
										<th>Nama Categori</th>
									</tr>
								</thead>
								<tbody>
									
									<?php 
									while ($row = @mysqli_fetch_assoc($pilih_categories)){
									$cat_id = $row ['cat_id'];
									$cat_judul = $row ['cat_judul'];
									
									echo "<tr>";
									echo "<td>{$cat_id}</td>";
									echo "<td>{$cat_judul}</td>";
									echo "</tr>";
									}
									?>
								</tbody>
									</table>
					</div>
                    </div>
                    
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
