<?php
DEFINE('DB_USER', 'root');
DEFINE('DB_PASSWORD','root');
DEFINE('DB_HOST', 'localhost');
DEFINE('DB_NAME', 'CMS');
$connection = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
if (!$connection) {
    trigger_error('gagal konek ' . mysqli_connect_error());
} else {
    echo 'Berhasil konek';
}
?>
